/* Run with: node verify-libraries.js */
global.window=global;
require('../src/libraries/chapter-library.js');
require('../src/libraries/rules-library.js');
const groups=window.ASTARTES_CHAPTER_LIBRARY.verificationGroups;
let failures=[];
for(const [group,names] of Object.entries(groups)){
  for(const name of names){
    const det=window.ASTARTES_RULES_LIBRARY.lookupDetachment(name);
    const expected=det?.verification?.expected;
    if(!det) failures.push(`${group}: missing ${name}`);
    else if(det.status!=='ready') failures.push(`${group}: ${name} is ${det.status}`);
    else if(!expected) failures.push(`${group}: ${name} has no verification manifest`);
    else {
      const ruleExpected=expected.detachmentRules;
      const ruleCount=(det.rules||[]).length;
      const ruleOk=Number.isInteger(ruleExpected) ? ruleCount===ruleExpected : (ruleExpected&&typeof ruleExpected==='object' ? ruleCount>=(Number.isFinite(ruleExpected.min)?ruleExpected.min:0) && ruleCount<=(Number.isFinite(ruleExpected.max)?ruleExpected.max:Infinity) : ruleCount>0);
      if(!ruleOk) failures.push(`${name}: rules ${ruleCount}/${Number.isInteger(ruleExpected)?ruleExpected:(ruleExpected?.min!=null?`>=${ruleExpected.min}`:'>=1')}`);
      if((det.enhancements||[]).length!==expected.enhancements) failures.push(`${name}: enhancements ${(det.enhancements||[]).length}/${expected.enhancements}`);
      if((det.stratagems||[]).length!==expected.stratagems) failures.push(`${name}: stratagems ${(det.stratagems||[]).length}/${expected.stratagems}`);
      const actualNames=new Set((det.stratagems||[]).map(x=>x.name));
      for(const strat of expected.stratagemNames||[]) if(!actualNames.has(strat)) failures.push(`${name}: missing stratagem ${strat}`);
    }
  }
}
if(failures.length){console.error(failures.join('\n'));process.exit(1)}
console.log(`PASS: ${Object.values(groups).flat().length} verification detachment entries are internally consistent.`);
console.log(`Rules Library: ${window.ASTARTES_RULES_LIBRARY.manifest.readyDetachments} ready / ${window.ASTARTES_RULES_LIBRARY.manifest.totalDetachments} catalogued total.`);
